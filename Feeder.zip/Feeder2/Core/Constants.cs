﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feeder.Common
{
    class Constants
    {
        public const string FOLDER_DESCRIPTION = "Folder";
        public const string NEW_FOLDER = "New Folder";
        public const string FEEDS_FILENAME = "feeds.json";
    }
}
